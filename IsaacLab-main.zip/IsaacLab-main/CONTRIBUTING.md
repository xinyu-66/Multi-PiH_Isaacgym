# Contribution Guidelines

Isaac Lab is a community maintained project. We wholeheartedly welcome contributions to the project to make
the framework more mature and useful for everyone. These may happen in forms of bug reports, feature requests,
design proposals and more.

For general information on how to contribute see
<https://isaac-sim.github.io/IsaacLab/main/source/refs/contributing.html>.
