﻿omni.isaac.lab_tasks.utils.data_collector
=========================================

.. automodule:: omni.isaac.lab_tasks.utils.data_collector

    .. Rubric:: Classes

    .. autosummary::

        RobomimicDataCollector

Robomimic Data Collector
------------------------

.. autoclass:: RobomimicDataCollector
    :members:
    :show-inheritance:
